const myMongo = require('./myMongoDb')

 exports.addDriver = post =>{
   return myMongo.createDocument('driver', post)
 }
 exports.getDriverList = (x) =>{
 	return myMongo.getAllDrivers('driver', {findDriverWith: '100'})

}
exports.deleteDriver = (id) =>{
	return myMongo.deleteDocument('driver', id)
}

exports.updateDriversWage = (newWage, id) =>{

	return myMongo.updateDocument('driver', id, newWage)

}

