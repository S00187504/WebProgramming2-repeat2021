const mongoShared = require("./sharedMongoDb");
const db = mongoShared.getDb();
const ObjectID = require('./sharedMongoDb').ObjectID

exports.createDocument = (collection, newDocument) => {
  return db.collection(collection).insertOne(newDocument) 
 };
 exports.getAllDrivers = (collection) => {
  return db.collection(collection).find({findDriverWith: '100'}).toArray();
 };
 exports.deleteDocument = (collection, id) => {
  return db.collection(collection).deleteOne({_id: ObjectID(id)})
 };

 exports.updateDocument = (collection, id, newWage) => {
  return db.collection(collection).updateOne({ _id: ObjectID(id) }, {$set: {price: newWage}});
};

 
 