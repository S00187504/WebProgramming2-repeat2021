const multiparty = require('multiparty')


const posts=require('../DriverCrudOp')

exports.loadRoutes = app =>{


	app.delete('/driver/:id', (req,res)=>{
		posts.deleteDriver(req.params.id).then(data=>{
			res.send(data)
		})
	})


	app.get('/driver/:findDriverWith', (req, res) => {
		posts.getDriverList(req.params.findDriverWith).then(data=>{
			res.send(data)
		})
	})


	app.put('/driver/edit-driver/:id',async (req,res)=>{
		var form = new multiparty.Form();
		form.parse(req, async function(err, fields, files) {
			const wage = fields?.wage[0] || ''
			posts.updateDriversWage(wage, req.params.id).then(data=>{
				res.send(data)
			})
		});
	})

	app.post('/driver',async (req,res)=>{
		var form = new multiparty.Form();
		form.parse(req, async function(err, fields, files) {
			const post = {
				driverName: fields?.driverName[0] ||'',
				driverSecondName: fields?.driverSecondName[0] || '', 
				wage: fields?.wage[0] || '',
				team: fields?.team[0] || '',
				findDriverWith: fields?.findDriverWith[0] || '',

			}
			posts.addDriver(post).then(data=>{
				res.send(data)
			})
		});
	})
}














