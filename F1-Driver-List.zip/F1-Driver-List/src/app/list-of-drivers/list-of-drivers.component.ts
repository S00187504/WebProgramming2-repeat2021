import { Component, OnInit } from '@angular/core';
import { DriverCrudOp } from '../driver-services/drivers.service';

@Component({
  selector: 'app-list-of-drivers',
  templateUrl: './list-of-drivers.component.html',
  styleUrls: ['./list-of-drivers.component.css']
})
export class ListOfDriversComponent implements OnInit {


  Driver:any = [];
 
  constructor(private driversService: DriverCrudOp) { }
 
  ngOnInit(): void {
    this.driversService.GetDriversList().subscribe(res => {
      this.Driver =res;
    });    
  }
 
  delete(id:any, i:any) {
    console.log(id);
    if(window.confirm('go ahead?')) {
      this.driversService.deleteDrivers(id).subscribe(res => {
        this.Driver =res;
      })
       window.location.reload()
      
    }
  }
}
