import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddDriversComponent } from './add-drivers/add-drivers.component';
import { DetailsOfDriverComponent } from './details-of-driver/details-of-driver.component';
import { ListOfDriversComponent } from './list-of-drivers/list-of-drivers.component';

const routes: Routes = [
  { path: 'list-drivers', component: ListOfDriversComponent }, 
  { path: 'add-driver', component: AddDriversComponent },
  { path: 'edit-driver/:id', component: DetailsOfDriverComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
