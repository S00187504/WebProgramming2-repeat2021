export class Drivers {
    _id!: String;
    driverName!: String;
    team!: String;
    wage!: Number;
    driverSecondName!: String;

}