import { Injectable } from '@angular/core';
import { Drivers } from './Drivers';
import { catchError, map } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DriverCrudOp {

  // Node/Express API
  REST_API: string = 'http://localhost:3002/driver/';
 
  // Http Header
  httpHeaders = new HttpHeaders().set('Content-Type', 'application/json');
  router: any;
 
  constructor(private httpClient: HttpClient) { }
 
   
   AddDriver(data: Drivers): Observable<any> {
     let API_URL = `http://localhost:3002/driver/add-drivers`;
     return this.httpClient.post(API_URL, data)
       .pipe(
         catchError(this.handleError)
       )
   }
 
  // Get all objects
  GetDriversList():  Observable<any> {
    return this.httpClient.get('http://localhost:3002/driver/100',{ headers: this.httpHeaders })
    .pipe(map((res: any) => {
        return res || {}
      }),
      catchError(this.handleError)
    )
  }

   
  // Delete
  deleteDrivers(id:any): Observable<any> {
    return this.httpClient.delete(`http://localhost:3002/driver/${id}`, { headers: this.httpHeaders})
    .pipe(map((res: any) => {
      return res || {}
    }),
    catchError(this.handleError)
  )
}

 
  // Update
  updateDrivers(id:any, data:any): Observable<any> {
    console.log(data)
    return this.httpClient.put(`http://localhost:3002/driver/${id}/${data}`, { headers: this.httpHeaders })
      .pipe(
        catchError(this.handleError)
      )
  }
 
 
  // Error 
  private handleError(error: Response | any) {
    let errorMessage = '';
    if (error.status == 0) {
      // Handle client error
      errorMessage = error.error.message;
      this.router.navigate(['/error'])
    } 
    console.log(errorMessage);
    return throwError(errorMessage);
  }}
