import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsOfDriverComponent } from './details-of-driver.component';

describe('DetailsOfDriverComponent', () => {
  let component: DetailsOfDriverComponent;
  let fixture: ComponentFixture<DetailsOfDriverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetailsOfDriverComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailsOfDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
