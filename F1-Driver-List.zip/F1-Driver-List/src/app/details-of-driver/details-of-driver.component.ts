import { Component, OnInit, NgZone } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DriverCrudOp } from '../driver-services/drivers.service';
import { FormGroup, FormBuilder } from "@angular/forms";

@Component({
  selector: 'app-details-of-driver',
  templateUrl: './details-of-driver.component.html',
  styleUrls: ['./details-of-driver.component.css']
})
export class DetailsOfDriverComponent implements OnInit {

  getId: any;
  updateForm: FormGroup;
   
  constructor(
    public formBuilder: FormBuilder,
    private router: Router,
    private ngZone: NgZone,
    private activatedRoute: ActivatedRoute,
    private driversService: DriverCrudOp,
  ) {
    this.getId = this.activatedRoute.snapshot.paramMap.get('id');
 
    this.driversService.GetDriversList().subscribe(res => {
      this.updateForm.setValue({
        driverName: res[''],
        wage: res[''],
        team: res[''],
        driverSecondName: res['']
      });
    });
 
    this.updateForm = this.formBuilder.group({
      driverName: [''],
      wage: [''],
      team: [''],
      driverSecondName: ['']
    })
  }
 
  ngOnInit() { }
 

  onUpdate(id:any): any {

    var formData: any = new FormData();
    formData.append("wage", this.updateForm.get('wage')?.value);


    console.log(formData)

     fetch("http://localhost:3002/driver" + window.location.pathname, {
       method: "PUT",
        body: formData,  
      })
      window.location.reload()
    


  }

}
