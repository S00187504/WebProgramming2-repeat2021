import { Component, OnInit, NgZone, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { DriverCrudOp } from '../driver-services/drivers.service';
import { FormGroup, FormBuilder } from "@angular/forms";
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-drivers',
  templateUrl: './add-drivers.component.html',
  styleUrls: ['./add-drivers.component.css']
})
export class AddDriversComponent implements OnInit {
  form: FormGroup;

  constructor(
    private http: HttpClient,
    private driversService: DriverCrudOp,
    public formBuilder: FormBuilder,
    private router: Router,
    private ngZone: NgZone

  ) { 
    this.form = this.formBuilder.group({
      driverName: [''],
      wage: [''],
      team: [''],
      driverSecondName: ['']

    })
  }
 
  ngOnInit() { }
 
  onSubmit() {

    var formData: any = new FormData();
    formData.append("driverName", this.form.get('driverName')?.value);
    formData.append("driverSecondName", this.form.get('driverSecondName')?.value);
    formData.append("wage", this.form.get('wage')?.value);
    formData.append("team", this.form.get('team')?.value);
    formData.append("findDriverWith", 100);



     fetch("http://localhost:3002/driver", {
       method: "POST",
        body: formData,  
      }).then(()=>{
        window.location.reload()
      })

  }

}
